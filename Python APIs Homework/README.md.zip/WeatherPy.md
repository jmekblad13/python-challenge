
# Analysis
- Observed Trend 1 - The latitude vs. temperature plot shows that the highest temperatures are indeed closest to the equator.  Currently, the southern hemisphere has higher temperatures than the northern hemisphere.  Almost no southern hemisphere temperatures are below 50 degrees farenheit. 
- Observed Trend 2 - The latitude vs. humidity plot shows that humidity increases near the equator. Within 8 to 10 degrees latitude from the equator, there are no city with humidity less than 60%. 
- Observed Trend 3 - I did not notice a strong relationship between latitude and cloudiness or wind speed.  Instead, it appears that there may be some sort of bias in citipy or openweathermapi towards cities in the northern hemisphere.  Bias may not be the correct word, but if the random number generator picked completely random numbers, more southern hemisphere cities were filtered out by citipy or openweathermapi.  This could be because there are fewer weathermapi registered southern hemisphere or because the registered cities are further from the random coordinates that were randomly selected and northern hemisphere cities were picked instead.


```python
import matplotlib.pyplot as plt
import openweathermapy as ow
import pandas as pd
from citipy import citipy
from pprint import pprint
from random import random
import numpy as np
import requests
import datetime
from config import api_key
```

# Generate Cities List


```python
cities = []

for x in range(0,2000):
    ran_lat = np.random.uniform(-90,90)
    ran_lng = np.random.uniform(-180,180)
    
    city = citipy.nearest_city(ran_lat,ran_lng)

    name = city.city_name
    if name not in cities:
        cities.append(name)
        
len(cities)
```




    749



# Perform API Calls


```python
url = "http://api.openweathermap.org/data/2.5/weather?"
units = "imperial"

query_url = f"{url}appid={api_key}&units={units}&q="

shortened_city_list = []
temperature = []
humidity = []
latitude = []
longitude = []
cloudiness = []
wind_speed = []
count = 1

for city in cities:
    city_with_plus = city.replace(" ","+")
    print(city_with_plus)
    response = requests.get(query_url + city_with_plus).json()
    if response['cod'] != "404":
        shortened_city_list.append(city)
        temperature.append(response["main"]["temp"])
        humidity.append(response["main"]["humidity"])
        latitude.append(response["coord"]["lat"])
        longitude.append(response["coord"]["lon"])
        cloudiness.append(response["clouds"]["all"])
        wind_speed.append(response["wind"]["speed"])
        print("Processing Record " + str(count) + " " + city + " " + query_url + city_with_plus)
        count = count + 1
```

    mackenzie
    Processing Record 1 mackenzie http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mackenzie
    illoqqortoormiut
    rikitea
    Processing Record 2 rikitea http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=rikitea
    punta+arenas
    Processing Record 3 punta arenas http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=punta+arenas
    qaanaaq
    Processing Record 4 qaanaaq http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=qaanaaq
    mataura
    Processing Record 5 mataura http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mataura
    yunyang
    Processing Record 6 yunyang http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=yunyang
    lazaro+cardenas
    Processing Record 7 lazaro cardenas http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=lazaro+cardenas
    merauke
    Processing Record 8 merauke http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=merauke
    east+london
    Processing Record 9 east london http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=east+london
    bengkulu
    talnakh
    Processing Record 10 talnakh http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=talnakh
    new+norfolk
    Processing Record 11 new norfolk http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=new+norfolk
    ushuaia
    Processing Record 12 ushuaia http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ushuaia
    butaritari
    Processing Record 13 butaritari http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=butaritari
    axim
    Processing Record 14 axim http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=axim
    georgetown
    Processing Record 15 georgetown http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=georgetown
    takoradi
    Processing Record 16 takoradi http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=takoradi
    busselton
    Processing Record 17 busselton http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=busselton
    atuona
    Processing Record 18 atuona http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=atuona
    jamestown
    Processing Record 19 jamestown http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=jamestown
    mys+shmidta
    hofn
    Processing Record 20 hofn http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=hofn
    sitka
    Processing Record 21 sitka http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=sitka
    east+wenatchee+bench
    Processing Record 22 east wenatchee bench http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=east+wenatchee+bench
    bredasdorp
    Processing Record 23 bredasdorp http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=bredasdorp
    alghero
    Processing Record 24 alghero http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=alghero
    katha
    zlitan
    Processing Record 25 zlitan http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=zlitan
    kangaatsiaq
    Processing Record 26 kangaatsiaq http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kangaatsiaq
    ostersund
    Processing Record 27 ostersund http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ostersund
    touros
    Processing Record 28 touros http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=touros
    amderma
    hilo
    Processing Record 29 hilo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=hilo
    pozhva
    Processing Record 30 pozhva http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=pozhva
    agirish
    Processing Record 31 agirish http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=agirish
    flin+flon
    Processing Record 32 flin flon http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=flin+flon
    yeppoon
    Processing Record 33 yeppoon http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=yeppoon
    khuzhir
    Processing Record 34 khuzhir http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=khuzhir
    deputatskiy
    Processing Record 35 deputatskiy http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=deputatskiy
    pringsewu
    Processing Record 36 pringsewu http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=pringsewu
    taolanaro
    kodiak
    Processing Record 37 kodiak http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kodiak
    abilene
    Processing Record 38 abilene http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=abilene
    berlevag
    Processing Record 39 berlevag http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=berlevag
    vaini
    Processing Record 40 vaini http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=vaini
    plettenberg+bay
    Processing Record 41 plettenberg bay http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=plettenberg+bay
    albany
    Processing Record 42 albany http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=albany
    kissidougou
    Processing Record 43 kissidougou http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kissidougou
    lavrentiya
    Processing Record 44 lavrentiya http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=lavrentiya
    narayangarh
    Processing Record 45 narayangarh http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=narayangarh
    isangel
    Processing Record 46 isangel http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=isangel
    coahuayana
    Processing Record 47 coahuayana http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=coahuayana
    palabuhanratu
    konde
    storforshei
    Processing Record 48 storforshei http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=storforshei
    cape+town
    Processing Record 49 cape town http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=cape+town
    saint+george
    Processing Record 50 saint george http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=saint+george
    saint-philippe
    Processing Record 51 saint-philippe http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=saint-philippe
    hermanus
    Processing Record 52 hermanus http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=hermanus
    nioro
    Processing Record 53 nioro http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=nioro
    zhigansk
    Processing Record 54 zhigansk http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=zhigansk
    qui+nhon
    flinders
    Processing Record 55 flinders http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=flinders
    marzuq
    Processing Record 56 marzuq http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=marzuq
    kruisfontein
    Processing Record 57 kruisfontein http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kruisfontein
    belushya+guba
    ancud
    Processing Record 58 ancud http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ancud
    half+moon+bay
    Processing Record 59 half moon bay http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=half+moon+bay
    zalesovo
    Processing Record 60 zalesovo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=zalesovo
    cabo+san+lucas
    Processing Record 61 cabo san lucas http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=cabo+san+lucas
    yellowknife
    Processing Record 62 yellowknife http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=yellowknife
    hobart
    Processing Record 63 hobart http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=hobart
    augusto+correa
    Processing Record 64 augusto correa http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=augusto+correa
    las+vegas
    Processing Record 65 las vegas http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=las+vegas
    thompson
    Processing Record 66 thompson http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=thompson
    taltal
    Processing Record 67 taltal http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=taltal
    eureka
    Processing Record 68 eureka http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=eureka
    attawapiskat
    codrington
    Processing Record 69 codrington http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=codrington
    dingle
    Processing Record 70 dingle http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=dingle
    ust-nera
    Processing Record 71 ust-nera http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ust-nera
    tilichiki
    Processing Record 72 tilichiki http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=tilichiki
    dikson
    Processing Record 73 dikson http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=dikson
    broome
    Processing Record 74 broome http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=broome
    tsihombe
    helong
    Processing Record 75 helong http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=helong
    tuktoyaktuk
    Processing Record 76 tuktoyaktuk http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=tuktoyaktuk
    los+llanos+de+aridane
    Processing Record 77 los llanos de aridane http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=los+llanos+de+aridane
    pangkalanbuun
    Processing Record 78 pangkalanbuun http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=pangkalanbuun
    mahebourg
    Processing Record 79 mahebourg http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mahebourg
    puerto+ayora
    Processing Record 80 puerto ayora http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=puerto+ayora
    auki
    Processing Record 81 auki http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=auki
    olot
    Processing Record 82 olot http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=olot
    sorland
    Processing Record 83 sorland http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=sorland
    cherskiy
    Processing Record 84 cherskiy http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=cherskiy
    sept-iles
    Processing Record 85 sept-iles http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=sept-iles
    souillac
    Processing Record 86 souillac http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=souillac
    china
    Processing Record 87 china http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=china
    bambous+virieux
    Processing Record 88 bambous virieux http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=bambous+virieux
    pangnirtung
    Processing Record 89 pangnirtung http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=pangnirtung
    usinsk
    Processing Record 90 usinsk http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=usinsk
    carnarvon
    Processing Record 91 carnarvon http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=carnarvon
    vysokogornyy
    Processing Record 92 vysokogornyy http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=vysokogornyy
    ribeira+grande
    Processing Record 93 ribeira grande http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ribeira+grande
    severo-kurilsk
    Processing Record 94 severo-kurilsk http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=severo-kurilsk
    lagoa
    Processing Record 95 lagoa http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=lagoa
    cartagena
    Processing Record 96 cartagena http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=cartagena
    krasnousolskiy
    guerrero+negro
    Processing Record 97 guerrero negro http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=guerrero+negro
    puquio
    Processing Record 98 puquio http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=puquio
    nambucca+heads
    Processing Record 99 nambucca heads http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=nambucca+heads
    longyearbyen
    Processing Record 100 longyearbyen http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=longyearbyen
    geraldton
    Processing Record 101 geraldton http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=geraldton
    chagda
    port+alfred
    Processing Record 102 port alfred http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=port+alfred
    san+cristobal
    Processing Record 103 san cristobal http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=san+cristobal
    saint+anthony
    Processing Record 104 saint anthony http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=saint+anthony
    tuatapere
    Processing Record 105 tuatapere http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=tuatapere
    avarua
    Processing Record 106 avarua http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=avarua
    kapaa
    Processing Record 107 kapaa http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kapaa
    takanosu
    Processing Record 108 takanosu http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=takanosu
    fallon
    Processing Record 109 fallon http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=fallon
    port+blair
    Processing Record 110 port blair http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=port+blair
    airai
    Processing Record 111 airai http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=airai
    yar-sale
    Processing Record 112 yar-sale http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=yar-sale
    el+alto
    Processing Record 113 el alto http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=el+alto
    bluff
    Processing Record 114 bluff http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=bluff
    saskylakh
    Processing Record 115 saskylakh http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=saskylakh
    kahului
    Processing Record 116 kahului http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kahului
    mayo
    Processing Record 117 mayo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mayo
    pacific+grove
    Processing Record 118 pacific grove http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=pacific+grove
    kroya
    Processing Record 119 kroya http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kroya
    khatanga
    Processing Record 120 khatanga http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=khatanga
    martapura
    Processing Record 121 martapura http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=martapura
    lompoc
    Processing Record 122 lompoc http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=lompoc
    nicoya
    Processing Record 123 nicoya http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=nicoya
    tasiilaq
    Processing Record 124 tasiilaq http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=tasiilaq
    marsa+matruh
    Processing Record 125 marsa matruh http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=marsa+matruh
    broken+hill
    Processing Record 126 broken hill http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=broken+hill
    kavieng
    Processing Record 127 kavieng http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kavieng
    kloulklubed
    Processing Record 128 kloulklubed http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kloulklubed
    svetlaya
    Processing Record 129 svetlaya http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=svetlaya
    bagdarin
    Processing Record 130 bagdarin http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=bagdarin
    mbini
    Processing Record 131 mbini http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mbini
    srednekolymsk
    Processing Record 132 srednekolymsk http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=srednekolymsk
    martinsburg
    Processing Record 133 martinsburg http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=martinsburg
    mao
    Processing Record 134 mao http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mao
    hamilton
    Processing Record 135 hamilton http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=hamilton
    ivdel
    Processing Record 136 ivdel http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ivdel
    porto+belo
    Processing Record 137 porto belo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=porto+belo
    belaya+gora
    Processing Record 138 belaya gora http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=belaya+gora
    arraial+do+cabo
    Processing Record 139 arraial do cabo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=arraial+do+cabo
    nuuk
    Processing Record 140 nuuk http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=nuuk
    clyde+river
    Processing Record 141 clyde river http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=clyde+river
    astaneh-ye+ashrafiyeh
    Processing Record 142 astaneh-ye ashrafiyeh http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=astaneh-ye+ashrafiyeh
    beyneu
    Processing Record 143 beyneu http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=beyneu
    te+anau
    Processing Record 144 te anau http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=te+anau
    makakilo+city
    Processing Record 145 makakilo city http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=makakilo+city
    nemuro
    Processing Record 146 nemuro http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=nemuro
    zhezkazgan
    Processing Record 147 zhezkazgan http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=zhezkazgan
    sentyabrskiy
    chokurdakh
    Processing Record 148 chokurdakh http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=chokurdakh
    bethel
    Processing Record 149 bethel http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=bethel
    luderitz
    Processing Record 150 luderitz http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=luderitz
    leiyang
    Processing Record 151 leiyang http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=leiyang
    spearfish
    Processing Record 152 spearfish http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=spearfish
    nyurba
    Processing Record 153 nyurba http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=nyurba
    coquimbo
    Processing Record 154 coquimbo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=coquimbo
    leshukonskoye
    Processing Record 155 leshukonskoye http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=leshukonskoye
    tadine
    Processing Record 156 tadine http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=tadine
    gorno-chuyskiy
    quatre+cocos
    Processing Record 157 quatre cocos http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=quatre+cocos
    tokur
    Processing Record 158 tokur http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=tokur
    escanaba
    Processing Record 159 escanaba http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=escanaba
    mackay
    Processing Record 160 mackay http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mackay
    cidreira
    Processing Record 161 cidreira http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=cidreira
    namibe
    Processing Record 162 namibe http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=namibe
    tahta
    rawannawi
    husavik
    Processing Record 163 husavik http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=husavik
    maridi
    penzance
    Processing Record 164 penzance http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=penzance
    gisborne
    Processing Record 165 gisborne http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=gisborne
    thinadhoo
    Processing Record 166 thinadhoo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=thinadhoo
    bolungarvik
    kaya
    sataua
    mayumba
    Processing Record 167 mayumba http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mayumba
    shaartuz
    kieta
    Processing Record 168 kieta http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kieta
    esperance
    Processing Record 169 esperance http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=esperance
    naze
    Processing Record 170 naze http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=naze
    yumen
    Processing Record 171 yumen http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=yumen
    lebu
    Processing Record 172 lebu http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=lebu
    yulara
    Processing Record 173 yulara http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=yulara
    acarau
    vaitupu
    segou
    Processing Record 174 segou http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=segou
    torit
    yeletskiy
    torbay
    Processing Record 175 torbay http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=torbay
    gat
    Processing Record 176 gat http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=gat
    leningradskiy
    Processing Record 177 leningradskiy http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=leningradskiy
    kununurra
    Processing Record 178 kununurra http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kununurra
    okha
    Processing Record 179 okha http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=okha
    basqal
    Processing Record 180 basqal http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=basqal
    umzimvubu
    wladyslawowo
    Processing Record 181 wladyslawowo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=wladyslawowo
    salalah
    Processing Record 182 salalah http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=salalah
    nhulunbuy
    Processing Record 183 nhulunbuy http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=nhulunbuy
    nanortalik
    Processing Record 184 nanortalik http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=nanortalik
    mogoytuy
    Processing Record 185 mogoytuy http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mogoytuy
    vestmannaeyjar
    Processing Record 186 vestmannaeyjar http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=vestmannaeyjar
    mar+del+plata
    Processing Record 187 mar del plata http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mar+del+plata
    aflu
    upernavik
    Processing Record 188 upernavik http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=upernavik
    rocha
    Processing Record 189 rocha http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=rocha
    faanui
    Processing Record 190 faanui http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=faanui
    altamirano
    Processing Record 191 altamirano http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=altamirano
    esso
    Processing Record 192 esso http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=esso
    vardo
    Processing Record 193 vardo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=vardo
    la+asuncion
    Processing Record 194 la asuncion http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=la+asuncion
    chuy
    Processing Record 195 chuy http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=chuy
    pemangkat
    ahipara
    Processing Record 196 ahipara http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ahipara
    ballina
    Processing Record 197 ballina http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ballina
    novoseleznevo
    Processing Record 198 novoseleznevo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=novoseleznevo
    kautokeino
    Processing Record 199 kautokeino http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kautokeino
    kaitangata
    Processing Record 200 kaitangata http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kaitangata
    sindor
    Processing Record 201 sindor http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=sindor
    medina+del+campo
    Processing Record 202 medina del campo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=medina+del+campo
    akyab
    silver+city
    Processing Record 203 silver city http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=silver+city
    elk+city
    Processing Record 204 elk city http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=elk+city
    brae
    Processing Record 205 brae http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=brae
    abbeville
    Processing Record 206 abbeville http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=abbeville
    solana+beach
    Processing Record 207 solana beach http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=solana+beach
    quang+ngai
    Processing Record 208 quang ngai http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=quang+ngai
    bam
    Processing Record 209 bam http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=bam
    antofagasta
    Processing Record 210 antofagasta http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=antofagasta
    kavaratti
    Processing Record 211 kavaratti http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kavaratti
    aberdeen
    Processing Record 212 aberdeen http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=aberdeen
    barrow
    Processing Record 213 barrow http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=barrow
    rawson
    Processing Record 214 rawson http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=rawson
    kebemer
    sayyan
    Processing Record 215 sayyan http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=sayyan
    esil
    Processing Record 216 esil http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=esil
    akdepe
    Processing Record 217 akdepe http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=akdepe
    havelock
    Processing Record 218 havelock http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=havelock
    bonthe
    Processing Record 219 bonthe http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=bonthe
    vologda
    Processing Record 220 vologda http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=vologda
    fernandez
    Processing Record 221 fernandez http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=fernandez
    aykhal
    Processing Record 222 aykhal http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=aykhal
    bengkalis
    krasnoborsk
    Processing Record 223 krasnoborsk http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=krasnoborsk
    hirara
    Processing Record 224 hirara http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=hirara
    gamba
    Processing Record 225 gamba http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=gamba
    biankouma
    Processing Record 226 biankouma http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=biankouma
    meulaboh
    Processing Record 227 meulaboh http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=meulaboh
    buariki
    ponta+do+sol
    Processing Record 228 ponta do sol http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ponta+do+sol
    turukhansk
    Processing Record 229 turukhansk http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=turukhansk
    krasnoselkup
    kuryk
    Processing Record 230 kuryk http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kuryk
    stornoway
    ola
    Processing Record 231 ola http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ola
    khatassy
    Processing Record 232 khatassy http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=khatassy
    hithadhoo
    Processing Record 233 hithadhoo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=hithadhoo
    carbonia
    Processing Record 234 carbonia http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=carbonia
    idanre
    Processing Record 235 idanre http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=idanre
    angoche
    Processing Record 236 angoche http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=angoche
    provideniya
    Processing Record 237 provideniya http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=provideniya
    samarai
    Processing Record 238 samarai http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=samarai
    abdanan
    Processing Record 239 abdanan http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=abdanan
    mutis
    Processing Record 240 mutis http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mutis
    berdigestyakh
    Processing Record 241 berdigestyakh http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=berdigestyakh
    mullaitivu
    baruun-urt
    Processing Record 242 baruun-urt http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=baruun-urt
    barentu
    Processing Record 243 barentu http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=barentu
    ruatoria
    ayan
    Processing Record 244 ayan http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ayan
    morehead
    Processing Record 245 morehead http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=morehead
    ilulissat
    Processing Record 246 ilulissat http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ilulissat
    turka
    Processing Record 247 turka http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=turka
    the+valley
    Processing Record 248 the valley http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=the+valley
    huanuco
    Processing Record 249 huanuco http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=huanuco
    lorengau
    Processing Record 250 lorengau http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=lorengau
    nikolskoye
    Processing Record 251 nikolskoye http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=nikolskoye
    tiksi
    Processing Record 252 tiksi http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=tiksi
    smithers
    Processing Record 253 smithers http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=smithers
    kidal
    Processing Record 254 kidal http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kidal
    san+isidro
    Processing Record 255 san isidro http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=san+isidro
    mrirt
    palani
    Processing Record 256 palani http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=palani
    kyra
    jaggayyapeta
    Processing Record 257 jaggayyapeta http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=jaggayyapeta
    langenhagen
    Processing Record 258 langenhagen http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=langenhagen
    victoria
    Processing Record 259 victoria http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=victoria
    teguldet
    Processing Record 260 teguldet http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=teguldet
    fortuna
    Processing Record 261 fortuna http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=fortuna
    alekseyevka
    Processing Record 262 alekseyevka http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=alekseyevka
    katsuura
    Processing Record 263 katsuura http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=katsuura
    nacala
    Processing Record 264 nacala http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=nacala
    homer
    Processing Record 265 homer http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=homer
    aksha
    Processing Record 266 aksha http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=aksha
    bubaque
    Processing Record 267 bubaque http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=bubaque
    antequera
    Processing Record 268 antequera http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=antequera
    punta+alta
    Processing Record 269 punta alta http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=punta+alta
    naryan-mar
    Processing Record 270 naryan-mar http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=naryan-mar
    kikwit
    Processing Record 271 kikwit http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kikwit
    lichinga
    Processing Record 272 lichinga http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=lichinga
    sobolevo
    Processing Record 273 sobolevo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=sobolevo
    hobyo
    Processing Record 274 hobyo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=hobyo
    camacha
    Processing Record 275 camacha http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=camacha
    umm+lajj
    Processing Record 276 umm lajj http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=umm+lajj
    asyut
    Processing Record 277 asyut http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=asyut
    ostrovnoy
    Processing Record 278 ostrovnoy http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ostrovnoy
    saint-augustin
    Processing Record 279 saint-augustin http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=saint-augustin
    kurchum
    Processing Record 280 kurchum http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kurchum
    katobu
    Processing Record 281 katobu http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=katobu
    chadiza
    Processing Record 282 chadiza http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=chadiza
    afmadu
    malkangiri
    Processing Record 283 malkangiri http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=malkangiri
    pouebo
    Processing Record 284 pouebo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=pouebo
    wenling
    Processing Record 285 wenling http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=wenling
    ovsyanka
    Processing Record 286 ovsyanka http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ovsyanka
    port+lincoln
    Processing Record 287 port lincoln http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=port+lincoln
    wajima
    Processing Record 288 wajima http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=wajima
    vila+velha
    Processing Record 289 vila velha http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=vila+velha
    richards+bay
    Processing Record 290 richards bay http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=richards+bay
    nara
    Processing Record 291 nara http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=nara
    port+elizabeth
    Processing Record 292 port elizabeth http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=port+elizabeth
    laguna
    Processing Record 293 laguna http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=laguna
    arona
    Processing Record 294 arona http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=arona
    concepcion+del+oro
    Processing Record 295 concepcion del oro http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=concepcion+del+oro
    rosarito
    Processing Record 296 rosarito http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=rosarito
    yarmouth
    Processing Record 297 yarmouth http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=yarmouth
    kitui
    Processing Record 298 kitui http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kitui
    teeli
    Processing Record 299 teeli http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=teeli
    poum
    Processing Record 300 poum http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=poum
    barawe
    bay+roberts
    Processing Record 301 bay roberts http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=bay+roberts
    mersing
    Processing Record 302 mersing http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mersing
    lasa
    Processing Record 303 lasa http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=lasa
    hirado
    Processing Record 304 hirado http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=hirado
    biloela
    Processing Record 305 biloela http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=biloela
    vila
    Processing Record 306 vila http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=vila
    kodinar
    Processing Record 307 kodinar http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kodinar
    puksoozero
    Processing Record 308 puksoozero http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=puksoozero
    namatanai
    Processing Record 309 namatanai http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=namatanai
    srivardhan
    Processing Record 310 srivardhan http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=srivardhan
    prince+rupert
    Processing Record 311 prince rupert http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=prince+rupert
    aklavik
    Processing Record 312 aklavik http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=aklavik
    sumbe
    Processing Record 313 sumbe http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=sumbe
    lagos
    Processing Record 314 lagos http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=lagos
    saldanha
    Processing Record 315 saldanha http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=saldanha
    sao+filipe
    Processing Record 316 sao filipe http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=sao+filipe
    ulaangom
    Processing Record 317 ulaangom http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ulaangom
    russell
    Processing Record 318 russell http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=russell
    mapimi
    Processing Record 319 mapimi http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mapimi
    haines+junction
    Processing Record 320 haines junction http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=haines+junction
    grand+river+south+east
    khorramshahr
    Processing Record 321 khorramshahr http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=khorramshahr
    inirida
    Processing Record 322 inirida http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=inirida
    aswan
    Processing Record 323 aswan http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=aswan
    kenai
    Processing Record 324 kenai http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kenai
    san+patricio
    Processing Record 325 san patricio http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=san+patricio
    svetlogorsk
    Processing Record 326 svetlogorsk http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=svetlogorsk
    opuwo
    Processing Record 327 opuwo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=opuwo
    isla+aguada
    Processing Record 328 isla aguada http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=isla+aguada
    barentsburg
    kudahuvadhoo
    Processing Record 329 kudahuvadhoo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kudahuvadhoo
    mubi
    Processing Record 330 mubi http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mubi
    port+macquarie
    Processing Record 331 port macquarie http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=port+macquarie
    cartagena+del+chaira
    Processing Record 332 cartagena del chaira http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=cartagena+del+chaira
    coihaique
    Processing Record 333 coihaique http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=coihaique
    iqaluit
    Processing Record 334 iqaluit http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=iqaluit
    talcher
    Processing Record 335 talcher http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=talcher
    soata
    Processing Record 336 soata http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=soata
    filadelfia
    Processing Record 337 filadelfia http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=filadelfia
    port+hawkesbury
    Processing Record 338 port hawkesbury http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=port+hawkesbury
    la+orilla
    Processing Record 339 la orilla http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=la+orilla
    ellsworth
    Processing Record 340 ellsworth http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ellsworth
    miraflores
    Processing Record 341 miraflores http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=miraflores
    nizhneyansk
    minuri
    Processing Record 342 minuri http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=minuri
    temiscaming
    Processing Record 343 temiscaming http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=temiscaming
    glazov
    Processing Record 344 glazov http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=glazov
    farafangana
    Processing Record 345 farafangana http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=farafangana
    avera
    Processing Record 346 avera http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=avera
    dakar
    Processing Record 347 dakar http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=dakar
    louisbourg
    ugoofaaru
    Processing Record 348 ugoofaaru http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ugoofaaru
    oxford
    Processing Record 349 oxford http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=oxford
    atbasar
    Processing Record 350 atbasar http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=atbasar
    alofi
    Processing Record 351 alofi http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=alofi
    manitouwadge
    Processing Record 352 manitouwadge http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=manitouwadge
    ambulu
    Processing Record 353 ambulu http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ambulu
    vila+franca+do+campo
    Processing Record 354 vila franca do campo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=vila+franca+do+campo
    pevek
    Processing Record 355 pevek http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=pevek
    seddon
    Processing Record 356 seddon http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=seddon
    sao+gabriel+da+cachoeira
    Processing Record 357 sao gabriel da cachoeira http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=sao+gabriel+da+cachoeira
    hyeres
    Processing Record 358 hyeres http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=hyeres
    daru
    Processing Record 359 daru http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=daru
    kamakwie
    Processing Record 360 kamakwie http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kamakwie
    takestan
    Processing Record 361 takestan http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=takestan
    tandag
    Processing Record 362 tandag http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=tandag
    mumford
    Processing Record 363 mumford http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mumford
    morgan+city
    Processing Record 364 morgan city http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=morgan+city
    tongliao
    Processing Record 365 tongliao http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=tongliao
    diffa
    Processing Record 366 diffa http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=diffa
    anadyr
    Processing Record 367 anadyr http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=anadyr
    bud
    Processing Record 368 bud http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=bud
    north+bend
    Processing Record 369 north bend http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=north+bend
    sahrak
    ahuimanu
    Processing Record 370 ahuimanu http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ahuimanu
    izhma
    Processing Record 371 izhma http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=izhma
    shitanjing
    Processing Record 372 shitanjing http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=shitanjing
    shenjiamen
    Processing Record 373 shenjiamen http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=shenjiamen
    caravelas
    Processing Record 374 caravelas http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=caravelas
    kyren
    Processing Record 375 kyren http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kyren
    hartlepool
    Processing Record 376 hartlepool http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=hartlepool
    ampanihy
    Processing Record 377 ampanihy http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ampanihy
    yanam
    Processing Record 378 yanam http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=yanam
    ende
    Processing Record 379 ende http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ende
    biak
    Processing Record 380 biak http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=biak
    sur
    Processing Record 381 sur http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=sur
    whitehorse
    Processing Record 382 whitehorse http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=whitehorse
    norman+wells
    Processing Record 383 norman wells http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=norman+wells
    vestbygda
    ixtapa
    Processing Record 384 ixtapa http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ixtapa
    yelatma
    Processing Record 385 yelatma http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=yelatma
    bauta
    Processing Record 386 bauta http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=bauta
    nome
    Processing Record 387 nome http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=nome
    armeria
    Processing Record 388 armeria http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=armeria
    galiwinku
    chokwe
    cap-aux-meules
    Processing Record 389 cap-aux-meules http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=cap-aux-meules
    qingdao
    Processing Record 390 qingdao http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=qingdao
    kresna
    Processing Record 391 kresna http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kresna
    karamay
    sibolga
    Processing Record 392 sibolga http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=sibolga
    sao+joao+da+barra
    Processing Record 393 sao joao da barra http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=sao+joao+da+barra
    morondava
    Processing Record 394 morondava http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=morondava
    taoudenni
    Processing Record 395 taoudenni http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=taoudenni
    springbok
    Processing Record 396 springbok http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=springbok
    bandeirantes
    Processing Record 397 bandeirantes http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=bandeirantes
    kilmez
    beringovskiy
    Processing Record 398 beringovskiy http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=beringovskiy
    rakhya
    leh
    Processing Record 399 leh http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=leh
    never
    Processing Record 400 never http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=never
    mul
    Processing Record 401 mul http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mul
    jinchang
    Processing Record 402 jinchang http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=jinchang
    muzhi
    Processing Record 403 muzhi http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=muzhi
    idlib
    Processing Record 404 idlib http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=idlib
    saleaula
    anloga
    Processing Record 405 anloga http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=anloga
    adamovka
    Processing Record 406 adamovka http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=adamovka
    dustlik
    Processing Record 407 dustlik http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=dustlik
    northam
    Processing Record 408 northam http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=northam
    saint-francois
    Processing Record 409 saint-francois http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=saint-francois
    hasaki
    Processing Record 410 hasaki http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=hasaki
    manta
    Processing Record 411 manta http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=manta
    california+city
    Processing Record 412 california city http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=california+city
    havre-saint-pierre
    Processing Record 413 havre-saint-pierre http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=havre-saint-pierre
    thayetmyo
    Processing Record 414 thayetmyo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=thayetmyo
    sauda
    Processing Record 415 sauda http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=sauda
    yankton
    Processing Record 416 yankton http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=yankton
    veverska+bityska
    Processing Record 417 veverska bityska http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=veverska+bityska
    san+vicente
    Processing Record 418 san vicente http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=san+vicente
    egvekinot
    Processing Record 419 egvekinot http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=egvekinot
    honiara
    Processing Record 420 honiara http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=honiara
    port+hardy
    Processing Record 421 port hardy http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=port+hardy
    kalmunai
    Processing Record 422 kalmunai http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kalmunai
    palestina
    Processing Record 423 palestina http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=palestina
    hennenman
    Processing Record 424 hennenman http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=hennenman
    harper
    Processing Record 425 harper http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=harper
    agua+buena
    Processing Record 426 agua buena http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=agua+buena
    strezhevoy
    Processing Record 427 strezhevoy http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=strezhevoy
    tirau
    Processing Record 428 tirau http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=tirau
    gizo
    Processing Record 429 gizo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=gizo
    viligili
    utiroa
    labutta
    pirai+do+sul
    Processing Record 430 pirai do sul http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=pirai+do+sul
    grindavik
    Processing Record 431 grindavik http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=grindavik
    morwa
    Processing Record 432 morwa http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=morwa
    shestakovo
    Processing Record 433 shestakovo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=shestakovo
    saint-pierre
    Processing Record 434 saint-pierre http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=saint-pierre
    nelson+bay
    Processing Record 435 nelson bay http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=nelson+bay
    kostomuksha
    Processing Record 436 kostomuksha http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kostomuksha
    rio+gallegos
    Processing Record 437 rio gallegos http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=rio+gallegos
    bac+lieu
    southbridge
    Processing Record 438 southbridge http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=southbridge
    margate
    Processing Record 439 margate http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=margate
    phalombe
    Processing Record 440 phalombe http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=phalombe
    matadi
    Processing Record 441 matadi http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=matadi
    kamenka
    Processing Record 442 kamenka http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kamenka
    wamba
    Processing Record 443 wamba http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=wamba
    acari
    Processing Record 444 acari http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=acari
    gravdal
    Processing Record 445 gravdal http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=gravdal
    scarborough
    Processing Record 446 scarborough http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=scarborough
    port+moresby
    Processing Record 447 port moresby http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=port+moresby
    oranjemund
    Processing Record 448 oranjemund http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=oranjemund
    kodinsk
    Processing Record 449 kodinsk http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kodinsk
    kampene
    Processing Record 450 kampene http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kampene
    tracy
    Processing Record 451 tracy http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=tracy
    whitianga
    Processing Record 452 whitianga http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=whitianga
    port-gentil
    Processing Record 453 port-gentil http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=port-gentil
    san-pedro
    Processing Record 454 san-pedro http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=san-pedro
    klaksvik
    Processing Record 455 klaksvik http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=klaksvik
    ternate
    Processing Record 456 ternate http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ternate
    saebovik
    meyungs
    ngukurr
    peniche
    Processing Record 457 peniche http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=peniche
    sayanskiy
    cravo+norte
    Processing Record 458 cravo norte http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=cravo+norte
    lima
    Processing Record 459 lima http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=lima
    himora
    nguiu
    portland
    Processing Record 460 portland http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=portland
    buala
    Processing Record 461 buala http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=buala
    fomboni
    Processing Record 462 fomboni http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=fomboni
    sioux+lookout
    Processing Record 463 sioux lookout http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=sioux+lookout
    peachland
    Processing Record 464 peachland http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=peachland
    grand+gaube
    Processing Record 465 grand gaube http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=grand+gaube
    weston
    Processing Record 466 weston http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=weston
    artyk
    la+romana
    Processing Record 467 la romana http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=la+romana
    davidson
    Processing Record 468 davidson http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=davidson
    mocuba
    Processing Record 469 mocuba http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mocuba
    caucaia
    Processing Record 470 caucaia http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=caucaia
    mutsamudu
    eldorado
    Processing Record 471 eldorado http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=eldorado
    west+chester
    Processing Record 472 west chester http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=west+chester
    kochinda
    Processing Record 473 kochinda http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kochinda
    samusu
    villiers
    Processing Record 474 villiers http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=villiers
    port+augusta
    Processing Record 475 port augusta http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=port+augusta
    ponnani
    Processing Record 476 ponnani http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ponnani
    acin
    saint-denis
    Processing Record 477 saint-denis http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=saint-denis
    soyo
    Processing Record 478 soyo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=soyo
    cedar+city
    Processing Record 479 cedar city http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=cedar+city
    phalaborwa
    Processing Record 480 phalaborwa http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=phalaborwa
    xiongzhou
    Processing Record 481 xiongzhou http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=xiongzhou
    klyuchi
    Processing Record 482 klyuchi http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=klyuchi
    santa+fe
    Processing Record 483 santa fe http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=santa+fe
    linda
    Processing Record 484 linda http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=linda
    carlagan
    Processing Record 485 carlagan http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=carlagan
    tanete
    Processing Record 486 tanete http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=tanete
    fez
    Processing Record 487 fez http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=fez
    san+quintin
    Processing Record 488 san quintin http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=san+quintin
    palmer
    Processing Record 489 palmer http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=palmer
    mbigou
    Processing Record 490 mbigou http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mbigou
    camopi
    Processing Record 491 camopi http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=camopi
    susangerd
    Processing Record 492 susangerd http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=susangerd
    mecca
    Processing Record 493 mecca http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mecca
    kisangani
    Processing Record 494 kisangani http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kisangani
    moyale
    Processing Record 495 moyale http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=moyale
    tabou
    Processing Record 496 tabou http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=tabou
    corinto
    Processing Record 497 corinto http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=corinto
    skalistyy
    komsomolskiy
    Processing Record 498 komsomolskiy http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=komsomolskiy
    puerto+madryn
    Processing Record 499 puerto madryn http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=puerto+madryn
    great+falls
    Processing Record 500 great falls http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=great+falls
    nouadhibou
    Processing Record 501 nouadhibou http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=nouadhibou
    novikovo
    Processing Record 502 novikovo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=novikovo
    marv+dasht
    manadhoo
    Processing Record 503 manadhoo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=manadhoo
    aksarka
    Processing Record 504 aksarka http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=aksarka
    semnan
    Processing Record 505 semnan http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=semnan
    hammerfest
    Processing Record 506 hammerfest http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=hammerfest
    brownsville
    Processing Record 507 brownsville http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=brownsville
    chachapoyas
    Processing Record 508 chachapoyas http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=chachapoyas
    shahreza
    Processing Record 509 shahreza http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=shahreza
    scottsburgh
    tabas
    Processing Record 510 tabas http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=tabas
    mae+sot
    Processing Record 511 mae sot http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mae+sot
    suntar
    Processing Record 512 suntar http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=suntar
    eirunepe
    Processing Record 513 eirunepe http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=eirunepe
    jacareacanga
    Processing Record 514 jacareacanga http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=jacareacanga
    yenagoa
    Processing Record 515 yenagoa http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=yenagoa
    roald
    Processing Record 516 roald http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=roald
    verkhnyaya+inta
    Processing Record 517 verkhnyaya inta http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=verkhnyaya+inta
    dawei
    Processing Record 518 dawei http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=dawei
    cheney
    Processing Record 519 cheney http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=cheney
    novoagansk
    Processing Record 520 novoagansk http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=novoagansk
    mingshui
    Processing Record 521 mingshui http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mingshui
    sorvag
    alice+springs
    Processing Record 522 alice springs http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=alice+springs
    bukachacha
    Processing Record 523 bukachacha http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=bukachacha
    tacoronte
    Processing Record 524 tacoronte http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=tacoronte
    buqayq
    whitefish
    Processing Record 525 whitefish http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=whitefish
    formosa+do+rio+preto
    Processing Record 526 formosa do rio preto http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=formosa+do+rio+preto
    gayeri
    Processing Record 527 gayeri http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=gayeri
    ust-ishim
    Processing Record 528 ust-ishim http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ust-ishim
    cabedelo
    Processing Record 529 cabedelo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=cabedelo
    singaraja
    Processing Record 530 singaraja http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=singaraja
    gari
    Processing Record 531 gari http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=gari
    grand+centre
    saint+andrews
    Processing Record 532 saint andrews http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=saint+andrews
    ayr
    Processing Record 533 ayr http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ayr
    arman
    Processing Record 534 arman http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=arman
    praia+da+vitoria
    Processing Record 535 praia da vitoria http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=praia+da+vitoria
    havoysund
    Processing Record 536 havoysund http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=havoysund
    salinopolis
    Processing Record 537 salinopolis http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=salinopolis
    novyy+urengoy
    Processing Record 538 novyy urengoy http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=novyy+urengoy
    luanda
    Processing Record 539 luanda http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=luanda
    asau
    roxana
    Processing Record 540 roxana http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=roxana
    mount+gambier
    Processing Record 541 mount gambier http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mount+gambier
    bezhetsk
    Processing Record 542 bezhetsk http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=bezhetsk
    zhanakorgan
    Processing Record 543 zhanakorgan http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=zhanakorgan
    namtsy
    Processing Record 544 namtsy http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=namtsy
    koryukivka
    Processing Record 545 koryukivka http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=koryukivka
    montepuez
    Processing Record 546 montepuez http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=montepuez
    hawkesbury
    Processing Record 547 hawkesbury http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=hawkesbury
    korla
    jumla
    Processing Record 548 jumla http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=jumla
    narsaq
    Processing Record 549 narsaq http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=narsaq
    kiama
    Processing Record 550 kiama http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kiama
    carauari
    Processing Record 551 carauari http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=carauari
    tessalit
    Processing Record 552 tessalit http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=tessalit
    arroyo
    Processing Record 553 arroyo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=arroyo
    kitimat
    Processing Record 554 kitimat http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kitimat
    chillan
    Processing Record 555 chillan http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=chillan
    chumikan
    Processing Record 556 chumikan http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=chumikan
    lac+du+bonnet
    Processing Record 557 lac du bonnet http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=lac+du+bonnet
    mujiayingzi
    Processing Record 558 mujiayingzi http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mujiayingzi
    batsfjord
    Processing Record 559 batsfjord http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=batsfjord
    lumsden
    Processing Record 560 lumsden http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=lumsden
    tamiahua
    Processing Record 561 tamiahua http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=tamiahua
    zalantun
    Processing Record 562 zalantun http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=zalantun
    barreirinhas
    Processing Record 563 barreirinhas http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=barreirinhas
    bilma
    Processing Record 564 bilma http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=bilma
    ust-maya
    Processing Record 565 ust-maya http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ust-maya
    katakwi
    Processing Record 566 katakwi http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=katakwi
    balsas
    Processing Record 567 balsas http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=balsas
    novyy+yarychiv
    Processing Record 568 novyy yarychiv http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=novyy+yarychiv
    vao
    Processing Record 569 vao http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=vao
    tawang
    Processing Record 570 tawang http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=tawang
    krasnyy
    Processing Record 571 krasnyy http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=krasnyy
    matara
    Processing Record 572 matara http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=matara
    cumaribo
    darhan
    Processing Record 573 darhan http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=darhan
    bolobo
    Processing Record 574 bolobo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=bolobo
    pochutla
    Processing Record 575 pochutla http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=pochutla
    ghanzi
    Processing Record 576 ghanzi http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ghanzi
    dickinson
    Processing Record 577 dickinson http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=dickinson
    shanhetun
    Processing Record 578 shanhetun http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=shanhetun
    yambio
    san+policarpo
    Processing Record 579 san policarpo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=san+policarpo
    wanning
    Processing Record 580 wanning http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=wanning
    fort+nelson
    Processing Record 581 fort nelson http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=fort+nelson
    ilhabela
    Processing Record 582 ilhabela http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ilhabela
    hervey+bay
    Processing Record 583 hervey bay http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=hervey+bay
    valer
    Processing Record 584 valer http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=valer
    aksu
    Processing Record 585 aksu http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=aksu
    arlit
    Processing Record 586 arlit http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=arlit
    puerto+escondido
    Processing Record 587 puerto escondido http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=puerto+escondido
    kemijarvi
    coffs+harbour
    Processing Record 588 coffs harbour http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=coffs+harbour
    si+bun+ruang
    Processing Record 589 si bun ruang http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=si+bun+ruang
    rockhampton
    Processing Record 590 rockhampton http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=rockhampton
    new+ulm
    Processing Record 591 new ulm http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=new+ulm
    lyuban
    Processing Record 592 lyuban http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=lyuban
    lhokseumawe
    Processing Record 593 lhokseumawe http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=lhokseumawe
    bure
    Processing Record 594 bure http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=bure
    gollere
    paris
    Processing Record 595 paris http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=paris
    chapais
    Processing Record 596 chapais http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=chapais
    matay
    Processing Record 597 matay http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=matay
    venice
    Processing Record 598 venice http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=venice
    bayir
    Processing Record 599 bayir http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=bayir
    castro
    Processing Record 600 castro http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=castro
    progreso
    Processing Record 601 progreso http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=progreso
    yangcun
    Processing Record 602 yangcun http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=yangcun
    el+limon
    Processing Record 603 el limon http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=el+limon
    silifke
    Processing Record 604 silifke http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=silifke
    rungata
    jalu
    Processing Record 605 jalu http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=jalu
    salug
    Processing Record 606 salug http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=salug
    stokmarknes
    Processing Record 607 stokmarknes http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=stokmarknes
    almeirim
    Processing Record 608 almeirim http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=almeirim
    muravlenko
    Processing Record 609 muravlenko http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=muravlenko
    jiazi
    Processing Record 610 jiazi http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=jiazi
    nairobi
    Processing Record 611 nairobi http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=nairobi
    truth+or+consequences
    Processing Record 612 truth or consequences http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=truth+or+consequences
    wasilla
    Processing Record 613 wasilla http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=wasilla
    amapa
    Processing Record 614 amapa http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=amapa
    ejido
    Processing Record 615 ejido http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ejido
    greensburg
    Processing Record 616 greensburg http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=greensburg
    bukama
    Processing Record 617 bukama http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=bukama
    khonuu
    bestobe
    Processing Record 618 bestobe http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=bestobe
    hami
    Processing Record 619 hami http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=hami
    krasnyy+luch
    Processing Record 620 krasnyy luch http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=krasnyy+luch
    coolum+beach
    Processing Record 621 coolum beach http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=coolum+beach
    xining
    Processing Record 622 xining http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=xining
    mount+darwin
    Processing Record 623 mount darwin http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mount+darwin
    belyy+yar
    Processing Record 624 belyy yar http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=belyy+yar
    gigmoto
    Processing Record 625 gigmoto http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=gigmoto
    mali
    Processing Record 626 mali http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mali
    bathsheba
    Processing Record 627 bathsheba http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=bathsheba
    raudeberg
    Processing Record 628 raudeberg http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=raudeberg
    san+jose
    Processing Record 629 san jose http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=san+jose
    banda+aceh
    Processing Record 630 banda aceh http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=banda+aceh
    sinop
    Processing Record 631 sinop http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=sinop
    zyryanka
    Processing Record 632 zyryanka http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=zyryanka
    manzanillo
    Processing Record 633 manzanillo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=manzanillo
    pisco
    Processing Record 634 pisco http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=pisco
    casa+grande
    Processing Record 635 casa grande http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=casa+grande
    lengshuitan
    Processing Record 636 lengshuitan http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=lengshuitan
    nieuw+amsterdam
    Processing Record 637 nieuw amsterdam http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=nieuw+amsterdam
    tromso
    Processing Record 638 tromso http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=tromso
    hay+river
    Processing Record 639 hay river http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=hay+river
    beloha
    Processing Record 640 beloha http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=beloha
    mitu
    Processing Record 641 mitu http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mitu
    rio+rancho
    Processing Record 642 rio rancho http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=rio+rancho
    sabzevar
    Processing Record 643 sabzevar http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=sabzevar
    soe
    Processing Record 644 soe http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=soe
    miri
    Processing Record 645 miri http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=miri
    bedesa
    Processing Record 646 bedesa http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=bedesa
    kysyl-syr
    Processing Record 647 kysyl-syr http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=kysyl-syr
    iralaya
    Processing Record 648 iralaya http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=iralaya
    nishihara
    Processing Record 649 nishihara http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=nishihara
    fairbanks
    Processing Record 650 fairbanks http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=fairbanks
    yerbogachen
    Processing Record 651 yerbogachen http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=yerbogachen
    roebourne
    Processing Record 652 roebourne http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=roebourne
    porangatu
    Processing Record 653 porangatu http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=porangatu
    deniliquin
    Processing Record 654 deniliquin http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=deniliquin
    mildura
    Processing Record 655 mildura http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=mildura
    sao+geraldo+do+araguaia
    Processing Record 656 sao geraldo do araguaia http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=sao+geraldo+do+araguaia
    tapalpa
    Processing Record 657 tapalpa http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=tapalpa
    krasnovishersk
    Processing Record 658 krasnovishersk http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=krasnovishersk
    omboue
    Processing Record 659 omboue http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=omboue
    gornyak
    Processing Record 660 gornyak http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=gornyak
    sena+madureira
    Processing Record 661 sena madureira http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=sena+madureira
    roncesvalles
    Processing Record 662 roncesvalles http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=roncesvalles
    birao
    Processing Record 663 birao http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=birao
    weyburn
    Processing Record 664 weyburn http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=weyburn
    bingol
    Processing Record 665 bingol http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=bingol
    ilebo
    Processing Record 666 ilebo http://api.openweathermap.org/data/2.5/weather?appid=5bf423bd383fb0cb5155fc161cbe794f&units=imperial&q=ilebo
    tidore
    


```python
weather_dict = {
    "City": shortened_city_list,
    "Latitude": latitude,
    "Longitude": longitude,
    "Temperature": temperature,
    "Humidity": humidity,
    "Cloudiness": cloudiness,
    "Wind Speed": wind_speed
}
weather_data = pd.DataFrame(weather_dict)
weather_data.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>City</th>
      <th>Cloudiness</th>
      <th>Humidity</th>
      <th>Latitude</th>
      <th>Longitude</th>
      <th>Temperature</th>
      <th>Wind Speed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>mackenzie</td>
      <td>20</td>
      <td>86</td>
      <td>55.34</td>
      <td>-123.09</td>
      <td>28.40</td>
      <td>2.24</td>
    </tr>
    <tr>
      <th>1</th>
      <td>rikitea</td>
      <td>88</td>
      <td>100</td>
      <td>-23.12</td>
      <td>-134.97</td>
      <td>79.98</td>
      <td>13.44</td>
    </tr>
    <tr>
      <th>2</th>
      <td>punta arenas</td>
      <td>40</td>
      <td>70</td>
      <td>-53.16</td>
      <td>-70.91</td>
      <td>42.80</td>
      <td>16.11</td>
    </tr>
    <tr>
      <th>3</th>
      <td>qaanaaq</td>
      <td>44</td>
      <td>100</td>
      <td>77.48</td>
      <td>-69.36</td>
      <td>-10.02</td>
      <td>4.05</td>
    </tr>
    <tr>
      <th>4</th>
      <td>mataura</td>
      <td>92</td>
      <td>67</td>
      <td>-46.19</td>
      <td>168.86</td>
      <td>52.71</td>
      <td>19.71</td>
    </tr>
  </tbody>
</table>
</div>




```python
weather_data.count()
```




    City           666
    Cloudiness     666
    Humidity       666
    Latitude       666
    Longitude      666
    Temperature    666
    Wind Speed     666
    dtype: int64




```python
current_datetime = datetime.datetime.now().strftime("%m/%d/%Y")
current_datetime
```




    '03/12/2018'



# Latitude vs. Temperature Plot


```python
plt.scatter(weather_data["Latitude"], weather_data["Temperature"], edgecolor="black", linewidths=1, marker="o", alpha=0.8)

plt.title("Latitude vs Temperature (F) (" + current_datetime + ")")
plt.ylabel("Temperature (F)")
plt.xlabel("Latitude")
plt.grid(True)
plt.xlim([-100, 100])
plt.ylim([-50, 120])

# Save the figure
plt.savefig("Latitude_Temperature.png")

# Show plot
plt.show()
```


![png](output_10_0.png)


# Latitude vs. Humidity Plot


```python
plt.scatter(weather_data["Latitude"], weather_data["Humidity"], edgecolor="black", linewidths=1, marker="o", alpha=0.8)

plt.title("Latitude vs. Humidity (%) (" + current_datetime + ")")
plt.ylabel("Humidity")
plt.xlabel("Latitude")
plt.grid(True)
plt.xlim([-100, 100])
plt.ylim([-5, 105])

# Save the figure
plt.savefig("Latitude_Humidity.png")

# Show plot
plt.show()
```


![png](output_12_0.png)


# Latitude vs. Cloudiness Plot


```python
plt.scatter(weather_data["Latitude"], weather_data["Cloudiness"], edgecolor="black", linewidths=1, marker="o", alpha=0.8)

plt.title("Latitude vs. Cloudiness (%) (" + current_datetime + ")")
plt.ylabel("Cloudiness")
plt.xlabel("Latitude")
plt.grid(True)
plt.xlim([-100, 100])
plt.ylim([-5, 105])

# Save the figure
plt.savefig("Latitude_Cloudiness.png")

# Show plot
plt.show()
```


![png](output_14_0.png)


# Latitude vs. Wind Speed Plot


```python
plt.scatter(weather_data["Latitude"], weather_data["Wind Speed"], edgecolor="black", linewidths=1, marker="o", alpha=0.8)

plt.title("Latitude vs. Wind Speed (mph) (" + current_datetime + ")")
plt.ylabel("Wind Speed")
plt.xlabel("Latitude")
plt.grid(True)
plt.xlim([-100, 100])
plt.ylim([-5, 50])

# Save the figure
plt.savefig("Latitude_Wind_Speed.png")

# Show plot
plt.show()
```


![png](output_16_0.png)



```python
weather_data.to_csv("weatherData.csv", index=False, header=True)
```
